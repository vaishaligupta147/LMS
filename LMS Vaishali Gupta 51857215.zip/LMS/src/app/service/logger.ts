export class Logger {
    logMessage(msg: string, value: string) {
        console.log(msg + value);
    }

}