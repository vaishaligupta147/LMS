export interface UserDetails{
    name: string,
   
    subject: string,
    emailId: string,
    message: string
}