import { ColoringAltDirective } from './coloring-alt.directive';

describe('ColoringAltDirective', () => {
  it('should create an instance', () => {
    const directive = new ColoringAltDirective();
    expect(directive).toBeTruthy();
  });
});
