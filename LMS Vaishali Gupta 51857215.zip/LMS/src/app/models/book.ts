export class Book {
    id: number;
      title: string;
    author: string;
    noOfCopies: number;
    inStock: boolean;
    token: string;
    location: string;
}